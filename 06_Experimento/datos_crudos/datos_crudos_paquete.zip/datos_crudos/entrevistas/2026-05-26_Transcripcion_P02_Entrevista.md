# Transcripción de entrevista — P02

**Fecha de la sesión:** 2026-05-26
**Técnica:** Entrevista semiestructurada

---

ENTREVISTA P02
ID de evidencia: P02
Código del participante: P02
Rol: Veterinario / Administrador de clínica
Transcripción
Entrevistador: Buenas, estamos aquí con el doctor P02, el cual es el veterinario que nos va a ayudar para la entrevista. Voy a leer un poco el consentimiento para que comprendan de qué se trata esto. La entrevista forma parte de una investigación institucional orientada a diseño y desarrollo de un sistema de gestión para clínica veterinaria con soporte de inteligencia artificial.
Entrevistador: Su participación es completamente voluntaria, los datos obtenidos serán tratados de forma confidencial, se utilizarán únicamente con fines académicos e investigativos y no serán compartidos con terceros sin su autorización ofrecida. Asimismo, solicitamos su consentimiento para la evaluación de la grabación de audio o video durante la entrevista con el único propósito de facilitar el análisis de información. Las copiadas de dichas grabaciones serán manejadas de manera confidencial y utilizadas exclusivamente para la investigación.
P02: Gracias. Gracias. Otra vez, gracias por su gusto.
P02: Mi nombre es P02, soy médico veterinario, y voy a llegar aquí.
Entrevistador: Está bien. A continuación, con la permiso de usted confirmar que ha leído y comprendido el propósito de esta entrevista investigativa.
P02: Exactamente así.
Entrevistador: Participa de forma voluntaria y puede investigarse en cualquier momento si usted se quiere ser una.
P02: Listo.
Entrevistador: Autoriza el uso de su propuesta con fines académicos e investigativos.
P02: Claro.
Entrevistador: Autoriza la grabación de audio de las preguntas abiertas con fines exclusivos de las análisis investigativas.
Entrevistador: Vamos a seguir.
P02: Listo.
Entrevistador: Vamos a comenzar con la sección A, gestión operativa.
P02: Adelante.
Entrevistador: ¿Cómo se ejecuta actualmente la información clínica de los pacientes? Editoriales, diagnósticos y tratamientos.
P02: Bueno, nosotros manejamos una plataforma, la cual...
Entrevistador: ¿Puedo mencionar el nombre?
P02: Sí, lo puedes decir. La plataforma se llama PECACMICS, que es una plataforma de uso veterinario en la cual se puede registrar cualquier cuestión de agendar cita, inventario, también se puede agendar la cuestión de fichas médicas, y así abro el control de los pacientes que tenemos. Obviamente que es una plataforma que se prepara, que tiene los mejores paquetes. Lo tenemos de base para cumplir esas dos cosas.
Entrevistador: ¿Qué dificultades presenta cuando necesita consultar el interior de un paciente de cargamento? Por ejemplo, en un almenso o en un control de seguimiento.
P02: Que hay que poner bien, bien en la oficina. Claro, porque la verdad es que la tendrás que ajustar, porque si no, ¿dónde sale? Digamos que si usted escribe algo mal, pues no... La M no le va a salir, no va a salir. O le van a salir varios, o a veces se le confunde con una S más, no va a salir por el inicio.
Entrevistador: Exacto. ¿Cómo maneja el proceso de pobre y vacunación cuando una consulta? ¿Dónde se generan erróneos o demoras con mayor frecuencia?
P02: En la plataforma, porque igual depende de los específicos, si no, no pueden llegar a todos. O sea, a veces son... Creo que... De los que no tienen... Hay que ponerse el dato para poder generar la consulta.
Entrevistador: ¿Con qué frecuencia los clientes? Que no se presenten o cancelan su cita a último momento. ¿Qué impacto tiene eso? O sea, si hubo un impacto negativo, ¿por qué?
P02: Por el hecho de que... Cuando viene a jugar una agenda, me vuelve a hacer la idea de que tengo que hacer tal cosa a cierto horario, y si, obviamente, el cliente, el paciente como está, no lo traen a la consulta, eso va a perjudicar, uno, en la información económica del ingreso, y dos, también, en la calcula negativa, porque hay que preparar dos citas para ese paciente, ahí deja a otro paciente que no pueda también, para tener ese pensamiento.
Entrevistador: ¿Cómo gestiona la comunicación con los dueños de la mascota después de una consulta de seguimiento, consulta de exámenes o próxima cita?
P02: Bueno, por lo general, el seguimiento se hace a base de piedra, pie de bolsaje, un pie de bolsaje, el paciente viene, o un bolsaje no vea, lo puede prohibir, o viceversa, previsto por el paciente, para igualar su control o su seguimiento, más que todo.
Entrevistador: ¿Cómo controla el inventario de medicamentos y insumos? ¿Ha tenido problemas por patantes o por productos vencidos?
P02: No, por productos vencidos, bueno, sí, por la plataforma que te digo, no me da esa opción, pero la AIM, como está en inventario, si la AIM está en la plataforma, tienes opción de poder hacerlo en inventario, efectivamente.
Entrevistador: Vamos con la sección B, seguimiento del clínico y la sección nacional. ¿Cómo realiza el seguimiento de peso, crecimiento y estado nutricional de esos pacientes a lo largo del tiempo?
P02: O sea, por lo general, nosotros lo ponemos exactamente en forma física, que me refiero, que son las cartillas en las cuales entregamos al paciente, y cada consulta que viene se hace el control del peso, y ahí lo remedian con un control también.
Entrevistador: ¿Con qué frecuencia los dueños les consultan sobre la alimentación de sus tocas? ¿Cómo preparan esas recomendaciones actualmente?
P02: Por lo general, la verdad, la actualidad, la actualización se hizo de forma seguida, en primer lugar, yo me refiero a la comida orgánica, a la comida balanceada y a la alimentación correcta. ¿Cómo llegamos a eso? ¿Cómo comunicamos con el cliente? Siempre lo hacemos en la consulta.
Entrevistador: ¿Salgo a ofrecer una duda o no? Cuando un paciente sale con indicaciones médicas, medicación, dieta, protocolos, ¿qué es la preferencia que los dueños cumplen en esas indicaciones y cómo se entera siendo la gente?
P02: Por lo general, cuando es así, tratamos de darles un seguimiento. Digamos, tiene el paciente, los 73 días, y de repente cuando no nos cuentan, porque a veces le pregunto a los médicos si les ha quedado la medicación, y dicen, no, se me complica, no es suficiente. Ya nos cuentan que igual, suponen que el 100%, un 60% cumplen las indicaciones al pie de letra, y de repente no se me interesa nada.
Entrevistador: ¿Qué hace usted cuando un dueño le dice que se me acuerda no ha mejorado con la dieta o el protocolo que invitaron? ¿Cómo ajusta las indicaciones sin verlas físicamente?
P02: Por lo general, cuando le pregunto, cierro la puerta los días, y que no debe ser lo adecuado, siempre tengo una letra de diálogo para poder revisar, pero bueno, a veces se me cortó el tiempo en el hospital, o a veces porque no estoy disponible, bueno, ya lo sabes que tiene que presentar, acomodamos, le demandamos cierta medicación para poderla ayudar.
Entrevistador: Vamos ahora con la sección C, percepción sobre inteligencia artificial. ¿Qué tráfico familiarizado está actualmente con el uso de herramientas digitales en su práctica veterinaria? Opciones tienen, no utiliza ningún software, usa herramientas básicas, oja cálculo, grupo de mensajería o agendas digital, usa algún un software veterinario, aunque en funciones limitadas, un software veterinario completo con autonomía.
P02: O sea, como te mencioné, como solución podemos obtener, un limitado, porque todo lo hemos ocupado. Si quieres el completo, pues completo.
Entrevistador: ¿Qué tamaño de acuerdo está con que un sistema inteligente analice los datos médicos de pacientes para asumir el posible diagnóstico veterinario? El escala desde el número 5, el 1 es totalmente de acuerdo y el 5 es totalmente contrario.
P02: Confines de diagnóstico. Sí, confines de diagnóstico. La verdad es que sí, no estoy de acuerdo, porque igual, yo sé que es difícil como tal dar una guía que pueda ayudar en cierta parte, pero no sería correcto, porque igual cambia siempre, todo de forma diferente, a varios parámetros.
Entrevistador: En este caso sería más parámetros subvenidos.
P02: Exactamente.
Entrevistador: Pensando en su forma diaria, ¿qué tarea o proceso le genera más carga de trabajo eficiente que podría apoyarse con alguna herramienta de soporte? ¿Alguna herramienta de soporte? ¿En qué tarea le gustaría llegar?
P02: O sea, por lo general, más que todo, en la construcción de laboratorios, por ejemplo, cuando tengo que hacer una cita que le escribo a un paciente y le avisa, digo, si es de forma gratuita sería eso, ¿por qué? Porque la forma paga y obviamente es un poco exagerado. Y más que todo el tema policial, sería muy bueno para el veterinario. Apoyar frecuentemente al guía que directamente le ayude en esa cuestión.
Entrevistador: ¿Qué nivel de confianza le generaría que el sistema haga recomendaciones clínicas como apoyo a su juicio profesional? Opciones. Alta confianza, lo usaría como referencia directa a tomar decisiones. Confianza moderada, lo usaría como apoyo, pero siempre con validación propia. Baja confianza, prefiero pasar decisiones en sugerencias automatizadas. O no lo usaría y prefiere el método clínico adicional sin apoyo automatizado.
P02: Apoyaría la sugerencia como tal, más no como ser un tipo directo. Se está tomando el tratamiento del médico clínico, pero aceptaría la sugerencia, digamos como una confianza moderada.
Entrevistador: ¿Qué condición considera más importante para confiar en el sistema que intende financiar dentro de su clínica? Aquí puedes decirme varias opciones, digamos. La opción que tiene son que las recomendaciones estén recordadas en literaturas científicas, veterinarias y validadas. Que el veterinario pueda revisar y conocer todas las sugerencias antes de aplicarlas. Que sea fácil de usar, sin necesidad de capacitación prorrogada. Que los datos de los pacientes estén protegidos y no se comparten con terceros. Y que existan soportes técnicos disponibles y actualizaciones priorizadas.
P02: Primero la cuestión de los datos de los tareas que tienen que estar protegidas. Y la cuestión está de también medios de soporte, porque a veces hay ciertas dudas y a veces no se realiza como tal. Es un corte de forma ideal.
Entrevistador: Vamos con la última sección que es la sección B de criterios de reducción a ciertas herramientas, digamos. Si tuviera disponible mañana una herramienta que le ayude con la gestión de su clínica, ¿cuál sería el primer problema completo que necesitaría resolver para que usted la use desde el primer día?
P02: Bueno, como tal, yo diría que puede ser, como te mencionaba, la cuestión de agendar las citas o hacer los recordatorios. Más que todo, porque ciertos propietarios, las narcoticas, a veces, por trabajo, estudios, se olvidan de las cosas. Y a veces uno no puede estar pendiente de esa cuestión. Tratar de recordarle de formas prácticas. ¿Sabes qué? Los dos días seguidos, los dos días antes tenés que ofrecer la cosa, una vacunación, una interpretación.
Entrevistador: ¿Para qué se está formando mayor?
P02: Directamente.
Entrevistador: ¿Cuáles son las características? Además de las características, son indispensables para que usted y su equipo adopten una herramienta de trabajo sin resistencia. ¿Como tal?
P02: No, no, desde mi punto de vista, ninguna resistencia como tal. Si es algo nuevo que nos va a ayudar, como en finales, para innovar, tener un mejor control de nuestros pacientes y, obviamente, dar un mejor servicio, no hay ningún problema en esa cuestión.
Entrevistador: ¿Desde qué dispositiva accedería? Porque, preferentemente a la herramienta de su jornada laboral, las opciones que tenemos serían una computadora de escritorio o una laptop, una tablet, o un teléfono móvil o un smartphone. O también puede existir lo que se puede usar en cualquier dispositivo.
P02: Yo diría que en cualquier dispositivo, pero si estamos para, por lo general, si le pegamos a la mano el teléfono, el teléfono nos ayuda para hacer unos cientos de cosas. Diría más que todo el teléfono.
Entrevistador: ¿En una clínica ¿Qué frecuencia afecta a la conectividad por botes de internet? Una escala de 1 a 5, nunca, o, otra vez, 3 con mucha frecuencia.
P02: Actualmente, la verdad es que nunca hemos llegado a eso, nunca.
Entrevistador: ¿Existe algún proceso, situación o necesidad específica de esa clínica que no hayamos abordado en este periodista y que consideres relevante para el diseño de una herramienta de gestión?
P02: Los dispositivos establecidos están correctos. No hay ningún punto de problema.
Entrevistador: Muchas gracias.
