# Transcripción de entrevista — P06

**Fecha de la sesión:** 2026-07-27
**Técnica:** Entrevista semiestructurada

---

ENTREVISTA P06
ID de evidencia: P06
Código del participante: P06
Rol: Veterinario
Transcripción
Entrevistador: Muy buenas, estamos aquí con el Dr. P06 el cual nos va a ayudar con el tema de la entrevista. Primeramente vamos a leer un poco sobre el consentimiento para que sepa de que se trata la entrevista. Con esta y presente entrevista vamos a formar parte de una investigación institucional orientada al diseño y desarrollo de un sistema de gestión para clínica veterinaria con soporte a inteligencia artificial. Su participación es completamente voluntaria. Los datos obtenidos serán tratados de forma confidencial, utilizados únicamente con fines académicos e investigativos y no serán compartidos con terceros sin su autorización expresa. Así mismo solicitamos un consentimiento para realizar la grabación de audio o video durante la entrevista con el único propósito de facilitar el análisis de la información recopilada, dichas grabaciones serán manejadas de manera confidencial y utilizadas especialmente para esta investigación. A continuación con la entrevista usted confirma que ha leído y comprendido el propósito de esta investigación. Participa de forma voluntaria y puede retirarse en cualquier momento sin consecuencia alguna. Autoriza el uso de su propuesta con fines académicos e investigativos y autoriza la grabación de audio de las preguntas abiertas con fines inclusivos para el análisis investigativo. Vamos a comenzar con la sección A, gestión de operaciones actuales de la veterinaria. ¿Cómo realiza actualmente la información de clínica de los pacientes historiales, diagnósticos y tratamientos? ¿Qué dificultades enfrenta cuando necesita consultar el historial de un paciente rápidamente por ejemplo en una urgencia o en un control de seguimiento?
P06: Pongamos, si llega por el caso de abandonamiento, que no nos digan cuál fue el motivo, qué estuvo haciendo el perro, edad, a veces dicen no solo la rescate tal fecha pero según la edad aproximada o de qué alimentación lleva, o sea nos mientan en algún dato.
Entrevistador: ¿Cómo maneja el proceso de cobro y facturación tras una consulta donde genera errores de demora con mayor frecuencia?
P06: Los cobros, o sea cómo registramos los cobros, mediante el facturador SRE.
Entrevistador: ¿Cómo controla el inventario de medicamentos y insumos? ¿Ha tenido problemas por faltantes o productos vencidos?
P06: No, con productos vencidos casi no tanto porque las mismas empresas nos mandan la fecha de caducidad, entonces de ahí por faltantes a veces sí, pero es por falta de pedidos porque estamos en quevedo y casi algunos carros no entran hasta acá para dejar productos.
Entrevistador: ¿En el control de inventario de qué manera lo hace?
P06: Manual, o a veces sí los registramos y estamos viendo en Excel.
Entrevistador: ¿Con qué frecuencia los clientes no se presentan o cancelan su cita a último momento? ¿Qué impacto tiene eso en la clínica?
P06: Bueno, cuando casi no se acepta cita al menos que sea para cirugía pero ahí dependiendo la hora de llegada se lo gestiona.
Entrevistador: ¿Cómo gestiona la comunicación con los dueños de la mascota? ¿Después de una consulta, seguimiento de resultados, exámenes o próximas citas?
P06: Cuando vienen a consulta, bueno si es para dosis, les decimos tienen que traer pataloga o tienen que venir a la siguiente y nos manejamos por WhatsApp.
Entrevistador: Vamos con la siguiente sección, sección B, seguimiento de clínico y nutrición. ¿Cómo realiza el seguimiento del peso, crecimiento y estado nutricional de sus pacientes a lo largo del tiempo?
P06: Bueno, controlando el peso siempre lo dejamos en el canal y aparte en la ficha médica que nos lleva.
Entrevistador: ¿Con qué frecuencia los dueños le consultan sobre la alimentación de su mascota? ¿Cómo preparan esas recomendaciones actualmente?
P06: Casi no preguntan mucho, más ya cuando vienen curados con un problema digestivo es que nos cuentan. Le doy, qué sé yo, la sobra, que es por lo general lo que dicen les doy la sobra de lo que uno mismo come, entonces ahí vienen, fijamos, mencionando qué balanceo es apto para ellos por la raza, por la edad y si quieren preparar ya, una preparación ya la doy usando para ellos, aparte, no de sobras.
Entrevistador: ¿Cómo que tipo de comida le pueden hacer daño también?
P06: El uso de condimentos, sal y si es verdad tú puedes agregarles como pimientos, cebolla, eso les mandamos aparte.
Entrevistador: ¿Algo sano?
P06: Lechuga, zanahoria, avena.
Entrevistador: ¿Cuándo un paciente sale con indicaciones médicas como medicación, dieta, reposo ¿Qué tan frecuente es que los dueños cumplan esas indicaciones? ¿Y cómo se entera si no las cumplieron?
P06: Muy poco siguen las recomendaciones, por lo general también decimos que se queden aquí en observación siempre una noche o días, dependiendo por qué motivo hayan venido, cuando son por cirugía tratamos de que se queden aquí hospitalizados y cuando no desean la hospitalización y se los llevan, pues nos damos cuenta en la limpieza del herido, una herida infectada o un animal que no ha estado bien.
Entrevistador: ¿Qué hace usted cuando un dueño le dice que su mascota no ha mejorado con la dieta o el tratamiento indicado? ¿Cómo ajusta las indicaciones y verlas físicamente a la mascota?
P06: Bueno, si no ha mejorado tenemos que ver si es que en realidad siguieron las medicaciones que se les mandó y si no pues lo derivamos a otra clínica para que les hagan exámenes.
Entrevistador: Vamos con la sección C, percepción sobre la inteligencia artificial, hacia digamos implementar la inteligencia artificial en una clínica. ¿Qué tan familiarizado está actualmente con el uso de herramientas digitales en sus prácticas veterinarias? ¿Tiene opciones como puede ser que no utiliza ningún software o herramienta digital? ¿Uso de herramientas básicas como hojas de cálculo, grupos de mensajería o agendas digitales? ¿Uso de algún software veterinario aunque con funciones limitadas? ¿Y uso de un software veterinario completo con regularidad?
P06: No, no utiliza nada.
Entrevistador: ¿Qué tan de acuerdo está con que un sistema inteligente analice los datos clínicos del paciente para sugerir posibles diagnósticos al veterinario? ¿De una escala del 1 al 5? ¿Totalmente en desacuerdo 1? ¿Totalmente de acuerdo 5?
P06: Creo que un 3 o 4.
Entrevistador: Pensando en su jornada diaria ¿Qué tarea o proceso le genera más carga de trabajo y siente que puede apoyarse con alguna herramienta de soporte?
Entrevistador: Perdón. Pensando en su jornada diaria ¿Qué tarea o proceso de la clínica le genera más carga de trabajo y siente que puede apoyarse con alguna herramienta de soporte?
P06: Tal vez médicas, recordar tareas médicas.
Entrevistador: Siguiente pregunta ¿Qué nivel de confianza le generaría un sistema agarrando recomendaciones clínicas como apoyo de su posición profesional? ¿Le daría alta confianza? ¿Lo usaría como referencia directa de toma de decisiones? ¿Una confianza moderada? ¿Lo usaría como apoyo pero siempre con validación propia? ¿Baja confianza? ¿Prefiere basar su decisión en sugerencias automatizadas? ¿O no lo usaría y prefiere el método clínico tradicional sin apoyo automatizado?
P06: Lo usaría como apoyo.
Entrevistador: ¿Sería como una confianza moderada o alta?
P06: Moderada.
Entrevistador: ¿Qué condición considera más importante para confiar en un sistema con inteligencia artificial dentro de su clínica? Que las recomendaciones estén reparadas en literatura científica o veterinaria válida. Que el veterinario pueda revisar y corregir todas las evidencias antes de aplicarlas. Que sea fácil usar sin necesidad de capacitación prolongada. Que los datos de los pacientes estén protegidos y no se compartan junto del cero. Que existan soportes técnicos disponibles y actualizaciones periódicas. ¿Puede decirme dos de estas opciones? ¿Cuál le gustaría más?
P06: La de que el veterinario pueda revisar y corregir.
Entrevistador: ¿Y otra más?
P06: Las actualizaciones periódicas.
Entrevistador: Listo. Ahora vamos con la última sección. Que es la sección de criterios de adopción a este tipo de herramientas. Si usted tuviera disponible desde mañana una herramienta que le ayude con la gestión de su clínica ¿Cuál sería el primer problema concreto que necesitaría resolver para que usted la use desde el primer día?
P06: Registrar al paciente. Y hablar de una manera directa con la doctora, digamos. O sea, el registro, llevar un control de vacunas. Hablaba mucho de esto de los recordatorios de vacunas. Un historiador, que ahí ya dependerá de que cuando ya esté cerca de la hora de la vacuna le mande a la doctora.
Entrevistador: ¿Cuáles características son indispensables para que usted y su equipo adopten una nueva herramienta de trabajo sin resistencia? ¿Cuáles son características? Digamos que se le complicaría o sería una manera fácil que su equipo, o donde está en la clínica, ustedes adoptarían este tipo de herramientas. Digamos.
P06: El precio, perdón. El precio.
Entrevistador: ¿Se les haría complicado manejar este tipo de herramientas o no? ¿Han tenido un poco de experiencia con estas?
P06: Sí, manejábamos antes una. O sea, manejábamos una como de un mes nomás. Porque era práctico. O sea, una muestra gratis. Para ver cómo funcionaba. Pero ahí sería el precio por ustedes. Los sistemas operativos los meterían en el sitio. Y se va a dejar la nueva.
Entrevistador: ¿Desde qué dispositivo accedería preferentemente la herramienta durante su jornada laboral? Tenemos las opciones que podría hacer desde una computadora de escritorio o laptop. Una tablet. Un teléfono móvil. O indistinto, necesita acceso desde cualquier dispositivo.
P06: Que cuente al laptop. Laptop.
Entrevistador: ¿En su clínica con qué frecuencia enfrenta problemas de conectividad de cortes de internet? Tenemos de una escala de 1 al 5. Nunca o muy rara vez que es 1. Y 5 con mucha frecuencia.
Entrevistador: Y última pregunta ¿Existe algún proceso o situación con necesidad específica de su clínica que no hayamos abordado en esta entrevista y que considere relevante para el diseño de una herramienta de gestión?
P06: No.
Entrevistador: ¿Todos los temas que se han abordado?
P06: Listo.
Entrevistador: Muchas gracias.
 


 


