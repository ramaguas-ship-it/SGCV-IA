# Transcripción de entrevista — P03

**Fecha de la sesión:** 2026-07-21
**Técnica:** Entrevista semiestructurada

---

ENTREVISTA P03
ID de evidencia: P03
Código del participante: P03
Rol: Veterinario
Transcripción
Entrevistador: Estamos aquí con el Dr. P03, el cual nos va a llenar con una entrevista para la reproducción de datos para la clínica veterinaria con relación a la inteligencia artificial. Primeramente vamos a leer un poco qué es lo que se va a hacer en esta entrevista, que va a formar parte de la investigación institucional realizada al diseño y desarrollo del sistema de gestión para la clínica veterinaria con el soporte de inteligencia artificial. Su participación es completamente voluntaria.
Entrevistador: Los datos obtenidos serán tratados de forma confidencial, utilizando únicamente confines académicos e investigativos, y no serán compartidos con terceros sin su autorización expresa. Asimismo, solicitamos su consentimiento para realizar la grabación de audio o video durante la entrevista con el único propósito de facilitar el análisis de la populación. Dichas grabaciones serán manejadas de manera confidencial y utilizadas exclusivamente para esta investigación.
Entrevistador: A continuación de la entrevista, usted confirma que ha leído y comprendido el propósito de esta investigación. Participa de forma voluntaria y puede retirarse en cualquier momento sin consecuencias algunas. Autoriza el uso de sus respuestas con fines académicos e investigativos.
Entrevistador: Autoriza la grabación de audio de las preguntas abiertas con fines exclusivos de análisis investigativo. Vamos a comenzar con la primera sección de la entrevista. ¿Cómo acredita actualmente la información clínica del paciente? Historial, diagnóstico y tratamiento.
P03: Mediante Word. Sí, guardo documentos de Word y los guardo. Historia clínica y el nombre de las propietarias.
Entrevistador: ¿Qué dificultades enfrenta cuando necesita consultar el historial de un paciente rápidamente? Por ejemplo, en una urgencia o en un control de seguimiento.
P03: Guardar muchos documentos hace que tenga que buscarlo manualmente, se podría decir, y toma tiempo. Entonces, esa creo que será mi dificultad en el momento de querer tener el historial.
Entrevistador: ¿Cómo maneja el proceso de cobro y facturación para una consulta? ¿Dónde se generan errores o demoras con mayor frecuencia?
P03: En la resección de los datos de los propietarios. Pero normalmente hacemos factura electrónica.
Entrevistador: ¿Cómo controla el inventario de medicamentos e insumos? ¿Ha tenido algún problema por faltante o por producto vencido?
P03: No llevo inventario. Porque trabajamos solo dos, somos parejas y por eso confiamos en la clínica.
Entrevistador: Se encarga del inventario, ¿verdad?
P03: Sí.
Entrevistador: ¿Un cáncer presencial viene y te lo presenta o cancela su cita a último momento? ¿Qué impacto tiene esa clínica?
P03: Muy raro. Normalmente el pago, por ejemplo, en los casos de hospitalización se hace previo a ingresarlos y todo eso ha tenido un impacto positivo.
Entrevistador: ¿Cómo gestiona la comunicación con los dueños de la mascota después de una consulta, seguimiento, resultado de exámenes o próxima citación?
P03: Trato de hacerlo lo más honesto posible, sin dejar información importante en el aire. Trato de hacerlo más claro, preciso, para que se lleve una buena imagen de nuestro servicio en una consulta.
Entrevistador: Vamos con la sección B, seguimiento del clínico y nutrición. ¿Cómo se realizaría el seguimiento de peso, crecimiento y estado nutricional de su paciente a lo largo del tiempo?
P03: Normalmente nosotros llevamos un control de peso, tamaño en nuestro paciente semanalmente. Si son cachorros, nosotros hacemos un cronograma más o menos que está comprendido en seis meses. La primera cita la tienen en el día 10, la segunda en el día 21, la tercera en el mes y medio. Durante todas las venidas a la veterinaria, le vamos tomando el peso, la talla, para llevar el registro para ver si están bajo peso, si van ganando bien el peso. Si no, le vamos ajustando la proporción de alimento, los suplementos que también ayudan muchísimo en el tema de la ganancia de peso y el crecimiento o desarrollo de los mismos.
Entrevistador: ¿Con qué frecuencia los dueños le consultan sobre la alimentación de su mascota? ¿Cómo prepara esas recomendaciones?
P03: Casi no preguntan, pero nosotros hablamos de ello, porque normalmente ellos ya tienen una ideología alimentar a su perro muchas veces dándole comida casera o comprando por la situación económica que viven muchas familias o el país dándole alimentos de mala calidad, alimentos que podemos por el bolsillo adquirir. Y nosotros tratamos de recomendar, si le van a comprar croquetas o si le van a hacer la comida, que tenga las recomendaciones que nosotros le damos. Para así no tener problemas en un futuro por una mala alimentación que le estamos comprando en las croquetas o a su vez algún problema que se esté generando por la comida casera que nosotros le podemos brindar que algunos de los alimentos que consumimos nosotros son tóxicos para ellos, como el ajo, la cebolla, la alpaza, entonces eso tratamos de hacer para que no suceda problemas a futuro con el tema de la nutrición.
Entrevistador: Cuando un paciente sale con indicaciones de medicación, dieta, reposo, ¿qué tan frecuente es que los veños cumplan esas indicaciones?
P03: Nosotros hacemos chequeos todos los días, una vez que salen de la veterinaria, mediante mensajes de texto, llamadas o videollamadas, tratamos de asegurarnos de que nuestro pacientito que sale de alta continúe con su tratamiento para lograr su recuperación al 100%. Pero bajo esa obligación que nosotros mismos nos ponemos, de seguir haciendo el chequeo después de la alta medica.
Entrevistador: ¿Qué hace usted cuando un dueño le dice que su mascota no ha mejorado con aliento o el tratamiento indicador? ¿Cómo ajusta la indicación en si vela físicamente a la mujer?
P03: Es muy raro lo que pasa, pero haría una evaluación de los medicamentos que yo les he recetado para ver si se está cumpliendo la toma de los mismos y si se está llevando todo bien exactamente como les he mencionado y a pesar de eso sigue mal. Le hago un preanálisis, un análisis nuevamente, no preanálisis, para poder ver que le puedo agregar al tratamiento ya prescrito y eso para tratar de llegar a la solución definitiva que es recuperar al paciente.
Entrevistador: Vamos por la sección C, la sección sobre inteligencia artificial. ¿Qué tal familiarizado está actualmente con el uso de herramientas digitales en su práctica veterinaria? Opciones, diría que no utiliza ningún software o herramienta digital, uso de herramientas básicas como hojas de cálculo, grupos de mensajerías, uso de algún software veterinario aunque con funciones limitadas o un software veterinario completo con regulo de vida.
P03: Casi poco uso, poco uso, no tengo software con inteligencia artificial. Sí, sí trabajo con un grupo de mensajería, pero literalmente son de médicos veterinarios, no trabajan con inteligencia artificial, pero nada, trabajo sin inteligencia artificial por ahora.
Entrevistador: ¿Qué tal de acuerdo está con el sistema inteligente análisis de los datos clínicos del paciente para sugerir posibles diagnósticos al veterinario? 1. Totalmente en desacuerdo o 5. Totalmente de acuerdo?
P03: Totalmente de acuerdo.
Entrevistador: Pensando en su jornada diaria, ¿qué tareas o procesos le generan más carga de trabajo y siente que no puede apoyarse con alguna herramienta de soporte?
P03: El chequeo de los pacientes hospitalizados, eso es lo que hay que estar casi 100% enfocado en esto, el desgaste mental es bastante considerado porque al final del día terminas bastante agotado. Durante los primeros días que son críticos literalmente para un paciente que está bastante degradado de salud, la preocupación por verlo mejorar agota más. Entonces creo que eso no reemplaza la inteligencia artificial, ella te puede decir, hay que tomarle la presión, obviamente, le tomas la presión, lo ves, pinta, vomita, como otros síntomas, pero eso no te lo puede ayudar a hacer algún soporte por ahí.
Entrevistador: ¿Qué nivel de confianza le generaría que el sistema haga recomendaciones clínicas como apoyo a las opciones? Alta confianza, lo usaría como referencia directa a tomar decisiones. Confianza moderada, lo usaría como apoyo pero siempre con validación propia. Baja confianza, prefiero no basar decisiones en sugerencias automáticas. Última opción, no lo usaría, prefiero el método clínico tradicional sin apoyo automatizado. ¿Qué condición considera más importante para confiar en un sistema con inteligencia artificial dentro de su clínica? Que las recomendaciones estén guardadas en literatura científica veterinaria válida, que el veterinario pueda realizar y corregir todas las sugerencias antes de aplicarlas, que sea fácil de usar sin necesidad de capacitación prolongada, que los datos de los pacientes estén protegidos y no se comparten con terceros, que existan soportes técnicos disponibles y actualizaciones periódicas.
P03: Que el veterinario pueda realizar todas las recomendaciones a la hora. Esta es la verdad.
Entrevistador: Última sección, sección D. Si tuvieras disponibles de mañana una herramienta que le ayude con la gestión de su clínica, ¿cuál sería el primer problema completo que necesitaría resolver para que usted la use desde el primer día?
P03: Me gustaría tener un programa para poder llevar el historial clínico.
Entrevistador: ¿El historial de la clínica?
P03: Claro que sí, todos.
Entrevistador: ¿Está relacionado con el registro, el historial, los datos? ¿Y que solo usted ahí busca ya?
P03: Obviamente.
Entrevistador: ¿Se hace más rápido buscar?
P03: Sin duda.
Entrevistador: ¿Cuáles características son indispensables para que usted y su equipo adopten una nueva herramienta de trabajo sin resistencia?
P03: O sea, no tenemos problemas con adquirirlo, pero tampoco lo hemos visto literalmente con la necesidad. Porque es una veterinaria que recién empieza, ¿ok? Y entonces poco a poco uno va implementando cositas.
Entrevistador: ¿Desde qué dispositivos accedería preferentemente a la herramienta durante su jornada laboral? Opciones como computador de escritorio lácteo, tablet, teléfono móvil o indistinto necesito acceso desde cualquier dispositivo?
P03: Yo creo que en cualquier dispositivo, porque a veces estamos pendientes del teléfono, a veces estamos pendientes del lácteo, entonces creo que cualquiera sería bueno.
Entrevistador: ¿De su clínica con qué frecuencia enfrenta problemas de conectividad o cortes de internet? Escalas de 1 a 5. 1, nunca o muy rara vez. 5, con mucha frecuencia.
P03: Nunca.
Entrevistador: ¿Existe algún proceso de situación o necesidad específica de su clínica que no hayamos abogado en esta entrevista y que considera relevante para el diseño de una herramienta de gestión?
P03: Creo que en ninguna de todas están abordadas ahora. Listo, eso sería todo.
Entrevistador: Muchas gracias.
P03: Gracias.

